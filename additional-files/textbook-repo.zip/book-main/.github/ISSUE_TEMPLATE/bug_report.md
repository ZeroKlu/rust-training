---
name: Bug report
about: Create a report to help us improve
---

- I have searched open and closed issues and pull requests for duplicates, using these search terms:
  -
  -
  -
- I have checked the latest `main` branch to see if this has already been fixed, in this file:
  -

URL to the section(s) of the book with this problem:

Description of the problem:

Suggested fix:
