# const and static

The first edition of the book is no longer distributed with Rust's documentation.

If you came here via a link or web search, you may want to check out [the current
version of the book](../ch19-01-unsafe-rust.html#accessing-or-modifying-a-mutable-static-variable) instead.

If you have an internet connection, you can [find a copy distributed with
Rust
1.30](https://doc.rust-lang.org/1.30.0/book/first-edition/const-and-static.html).
