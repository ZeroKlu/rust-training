fn main() {
    // ANCHOR: here
    let x = 5;
    let y = x;

    println!("x = {}, y = {}", x, y);
    // ANCHOR_END: here
}
