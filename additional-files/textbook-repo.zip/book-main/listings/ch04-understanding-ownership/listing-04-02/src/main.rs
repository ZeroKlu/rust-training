fn main() {
    // ANCHOR: here
    let x = 5;
    let y = x;
    // ANCHOR_END: here
}
