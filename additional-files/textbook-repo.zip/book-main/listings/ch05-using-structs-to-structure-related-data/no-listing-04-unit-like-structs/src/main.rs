struct AlwaysEqual;

fn main() {
    let subject = AlwaysEqual;
}
