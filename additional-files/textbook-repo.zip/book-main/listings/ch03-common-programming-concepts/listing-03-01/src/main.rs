fn main() {
    let y = 6;
}
