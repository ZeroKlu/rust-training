fn main() {
    // ANCHOR: here
    let mut spaces = "   ";
    spaces = spaces.len();
    // ANCHOR_END: here
}
