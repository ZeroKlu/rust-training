fn main() {
    let x = 2.0; // f64

    let y: f32 = 3.0; // f32
}
