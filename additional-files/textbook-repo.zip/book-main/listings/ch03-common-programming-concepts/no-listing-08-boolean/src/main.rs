fn main() {
    let t = true;

    let f: bool = false; // with explicit type annotation
}
