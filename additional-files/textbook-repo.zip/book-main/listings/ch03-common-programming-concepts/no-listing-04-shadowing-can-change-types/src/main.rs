fn main() {
    // ANCHOR: here
    let spaces = "   ";
    let spaces = spaces.len();
    // ANCHOR_END: here
}
