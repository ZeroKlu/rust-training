fn main() {
    let guess = "42".parse().expect("Not a number!");
}
