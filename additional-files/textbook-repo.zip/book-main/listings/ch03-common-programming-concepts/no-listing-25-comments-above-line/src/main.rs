fn main() {
    // I’m feeling lucky today
    let lucky_number = 7;
}
