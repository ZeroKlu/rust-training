fn main() {
    let lucky_number = 7; // I’m feeling lucky today
}
