fn main() {
    let number = 3;

    if number {
        println!("number was three");
    }
}
